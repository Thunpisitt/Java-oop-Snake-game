package displayTimer;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class Counter extends JPanel{
	public static int t =10;

	static String time_counter="10";
	public Counter(){
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		time_counter = TimetoString(t);
		//setBackground(Color.BLACK);
		g.setFont(new Font("SansSerif",Font.BOLD,45));
		g.setColor(Color.RED);
		g.drawString(time_counter, 10, 50);
		
	}
	public String TimetoString(int t) {
		repaint();
		return String.valueOf(t);
		
		
	}
	/*public static void main(String [] args) {
		JFrame frame = new JFrame();
		frame.add(new Counter());
		frame.setSize(800,800);
		frame.setVisible(true);
		//frame.setFocusable(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}*/
		
	
	

	

}

