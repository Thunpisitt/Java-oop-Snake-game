package Control;
import displayTimer.Counter;
import Control.GameOver;

import java.awt.event.*;
import java.util.Random;
import java.awt.*;
import javax.swing.*;

public class MainScreen extends JPanel implements ActionListener, MouseMotionListener , ItemListener{
	
	
	JPanel Panel1_Information = new JPanel();
	JLabel InputName = new JLabel("Please enter your name : ");
	JTextField FillName = new JTextField(10);
	JLabel NameOutput = new JLabel("Name :       ");
	JLabel score = new JLabel("Score : "+0);
	
	JPanel Panel2_Setting = new JPanel();
	JRadioButton Black_Button = new JRadioButton("Black");
	JRadioButton Pink_Button = new JRadioButton("Pink");
	JRadioButton UseMouse_Button = new JRadioButton("Use Mouse");
	JLabel life = new JLabel("Your Life : "+3);
	
	JPanel Panel3_Control = new JPanel();
	JButton Left_Button = new JButton("Left");
	JButton Right_Button = new JButton("Right");
	JButton Up_Button = new JButton("Up");
	JButton Down_Button = new JButton("Down");
	
	
	
	int x = getX();
	int y = 400;
	int apple_x;
	int apple_y;
	int Score;
	int Apple_Position = 50;
	int Dot_Size = 20;
	Color textColor;
	int t = 0;
	Timer timer = new Timer(1000,new TimerListener());
	int timecounter=10; 
	//Random a = new Random();
	int p;
	int gameover = 3;
	int yourlife = 3;
	int l;
	
	MainScreen(String s){
		JFrame frame = new JFrame(s);
		setLayout(new BorderLayout());
		frame.add(Panel1_Information, BorderLayout.WEST);
		frame.add(Panel2_Setting, BorderLayout.EAST);
		frame.add(Panel3_Control, BorderLayout.SOUTH);
		frame.add(this, BorderLayout.CENTER);
		
		frame.setFocusable(true);
		
		
		Panel1_Information.setLayout(new FlowLayout());
		Panel1_Information.add(InputName);
		Panel1_Information.add(FillName);
		Panel1_Information.add(NameOutput);
		Panel1_Information.add(score);
		
		Panel2_Setting.setLayout(new GridLayout(4,1));
		Panel2_Setting.add(Black_Button);
		Panel2_Setting.add(Pink_Button);
		Panel2_Setting.add(life);
		Panel2_Setting.add(UseMouse_Button);
		Panel2_Setting.add(new Counter());
		
		Panel3_Control.setLayout(new FlowLayout());
		Panel3_Control.add(Left_Button);
		Panel3_Control.add(Right_Button);
		Panel3_Control.add(Up_Button);
		Panel3_Control.add(Down_Button);
		
		
		FillName.addActionListener(this);
		Black_Button.addItemListener(this);
		Pink_Button.addItemListener(this);
		Left_Button.addActionListener(this);
		Right_Button.addActionListener(this);
		Up_Button.addActionListener(this);
		Down_Button.addActionListener(this);
		UseMouse_Button.addActionListener(this);
		
		frame.setSize(800,800);
		frame.setVisible(true);
		//frame.setFocusable(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		new ActionInterpretor();
	}
	public class ActionInterpretor implements ActionListener{
		ActionInterpretor(){
			FillName.addActionListener(this);
		}
		public void actionPerformed(ActionEvent e) {
			String n = FillName.getText();
			String name = n;
			NameOutput.setText("Your name : "+name);
			timer.start();
		}
	}
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Font newfont = new Font("SansSerif",Font.BOLD,32);
		g.setFont(newfont);
		g.setColor(textColor);
		g.fillRect(x, y, 50, 50);
		g.setColor(Color.RED);
		//apple_x = a.nextInt(getWidth());
		//apple_y = a.nextInt(getHeight());
		g.fillOval(apple_x, apple_y, 50, 50);
	}
	



	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == Pink_Button) {
			Black_Button.setSelected(false);
			setBackground(Color.PINK);
			textColor = Color.BLACK;
		}
		else if (e.getSource() == Black_Button)
        {
            Pink_Button.setSelected(false);
            setBackground(Color.BLACK);
            textColor = Color.PINK;
        }
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		//timer.start();
		if (e.getActionCommand() == "Left") {
			x = x-20;
		}
		else if(e.getActionCommand() == "Right") {
			x = x+20;
		}else if(e.getActionCommand() == "Up") {
			y = y-20;
		}
		else if(e.getActionCommand() == "Down") {
			y = y+20;
		}
		else if (e.getActionCommand() == "Use Mouse") {
			if (t%2==0) {
				addMouseMotionListener(this);
				t++;
			}
			else if (t%1==0) {
				removeMouseMotionListener(this);
				t++;
			}
		}
		
		Function();
		repaint();
		
	}
	public void Function(){
		if (timecounter == 0) {
			locateApple();
			timecounter=10;
			gameover-=1;
			yourlife-=1;
			double l = (double)yourlife;
			life.setText("Your Life : "+l);
			if (gameover == 0) {
				gameover();
				timer.stop();
			}
			
			
			
			}
		else if((x==apple_x) && (y==apple_y)) {
			Score++;
			double s = Math.pow(Score, 2);
			int p = (int)s;
			score.setText("Score : "+p);
			timecounter=10;
			
			locateApple();
			}
		
		repaint();
		
}
	
		

		
	
	
	private void locateApple() {
		int r = (int)(Math.random()*Apple_Position);
		apple_x = (r*Dot_Size);
		
		r = (int)(Math.random()*Apple_Position);
		apple_y = (r*Dot_Size);
		
	}
	public void gameover() {
		JFrame GameOverframe = new JFrame();
		GameOverframe.add(new extendsClass("Game Over!!","new Score!!"));
		GameOverframe.setSize(800,800);
		GameOverframe.setVisible(true);
		GameOverframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String [] args) {
		new MainScreen("My Game");
	}




	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		x = e.getX();
		y = e.getY();
		Function();
		//locateApple();
		repaint();
	}




	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	class TimerListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			timecounter--;
			System.out.println(timecounter);
			Counter.t=timecounter;
			Function();
			
		}
		
	}

}


