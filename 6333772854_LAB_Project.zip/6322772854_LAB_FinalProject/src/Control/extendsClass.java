package Control;

import java.awt.*;

import javax.swing.*;

public class extendsClass extends GameOver{
	
	String n = "new High score!!";
	
	extendsClass(String f, String n){
		this.n = n;
	}
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		setBackground(Color.BLACK);
		g.setFont(new Font("SansSerif",Font.BOLD,45));
		g.setColor(Color.RED);
		g.drawString(f, 250, 350);
		g.setColor(Color.PINK);
		g.drawString(n, 250,400);
	}
	/*public static void main(String [] args) {
		JFrame frame = new JFrame();
		frame.add(new extendsClass("Game Over!!","new Score!!"));
		frame.setSize(400,400);
		frame.setVisible(true);
		//frame.setFocusable(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}*/

}
